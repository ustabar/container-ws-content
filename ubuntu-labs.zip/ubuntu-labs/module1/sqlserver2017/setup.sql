CREATE DATABASE LabData;
GO

USE LabData;
GO

CREATE TABLE Users (ID int, UserName nvarchar(max));
GO